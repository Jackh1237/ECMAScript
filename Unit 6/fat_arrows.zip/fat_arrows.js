function creatingLoops(x) {
    for (let i = 0; i < x; i++) {
          console.log(i);
     }
}
creatingLoops(20);

// TODO: Convert the creatingLoops() function into an arrow function.
